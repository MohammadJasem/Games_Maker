var cursors;





var objectToMove_apple;

var appleSprite_200440;

var objectToMove_apple;
var objectToMove_snake;

var appleSprite_200440;

var objectToMove_apple;
var objectToMove_snake;

var appleSprite_200440;

var objectToMove_apple;
var objectToMove_snake;
//GLOBAL_MOVING_GROUP_CODE
var appleSprite_200440;

var objectToMove_apple;
var objectToMove_snake;
//GLOBAL_MOVING_GROUP_CODE

var StartGame = {

    preload : function() {
//PRELOAD

//BCKGRND
	
//BCKGRND


//PAINTS

	game.load.image("apple", "/games_repositories/MJ1995/Games/Snake_2D_1.0/assets/img/apple.png");
	game.load.image("snake", "/games_repositories/MJ1995/Games/Snake_2D_1.0/assets/img/snake.png");
//PAINTS


//PRELOAD
    },

    create: function () {

	// Set up a Phaser controller for keyboard input.
    cursors = game.input.keyboard.createCursorKeys();
        
//CREATE

//STBCKGRND
	game.stage.backgroundColor = '#061f27';
//STBCKGRND



//PIXELS

	 appleSprite_200440 = game.add.sprite(440,200,"apple");
	appleSprite_200440.scale.setTo(0.3125, 0.3125);
	 snakeSprite_80220 = game.add.sprite(220,80,"snake");
	snakeSprite_80220.scale.setTo(0.3125, 0.3125);
//PIXELS



//F_CALL_EVENTS

appleSprite_200440.destroy();
randomPosition_200440();
objectToMove_snake = [snakeSprite_80220];
//F_CALL_EVENTS


//CREATE
    },

    update: function () {
//UPDATE

//F_CALL_UPDATE_FUNC

moving_80220();
//F_CALL_UPDATE_FUNC

//UPDATE
    },

	nextState: function(){
//NXTSTATE
	this.state.start('');
//NXTSTATE
    }

};


//EVENTS_FUNCTIONS


function randomPosition_200440 (){
	var pixelArr = [[220,80]];
	var fineToPut = false;
	while(!fineToPut){
		var randomX = Math.floor(Math.random() * 30 ) * 20,
		randomY = Math.floor(Math.random() * 22 ) * 20;
		var fineToPut = true;
		for(var i=0;i<pixelArr.length;i++)
			if(pixelArr[i][0] == randomX && pixelArr[i][1] == randomY)
				fineToPut = false;
		if(fineToPut){
			appleSprite_200440 = game.add.sprite(randomX, randomY, 'apple');
			appleSprite_200440.scale.setTo(0.3125, 0.3125);
		}
	}
}
var updateDelay = 0;
var new_direction = null;
var direction = 'right';
var addNew = false;
function moving_80220() {

	var keys = {esc:'F',space:'F',left:'T',right:'T',up:'T',down:'T'};
	//var keys = {'up':'T','down':'T','right':'T','left':'T'}
	cursors = game.input.keyboard.createCursorKeys();

    if (cursors.right.isDown && direction!='left' && keys['right'] == 'T')
        new_direction = 'right';
    else if (cursors.left.isDown && direction!='right' && keys['left'] == 'T')
        new_direction = 'left';
    else if (cursors.up.isDown && direction!='down' && keys['up'] == 'T')
        new_direction = 'up';
    else if (cursors.down.isDown && direction!='up' && keys['down'] == 'T')
        new_direction = 'down';

    updateDelay++;

   
    if (updateDelay % 15 == 0) {

        var firstCell = objectToMove_snake[objectToMove_snake.length - 1],
            lastCell = objectToMove_snake.shift(),
            oldLastCellx = lastCell.x,
            oldLastCelly = lastCell.y;

        if(new_direction){
            direction = new_direction;
            new_direction = null;
        }

        if(direction == 'right'){

            lastCell.x = firstCell.x + 20;
            lastCell.y = firstCell.y;
        }
        else if(direction == 'left'){
            lastCell.x = firstCell.x - 20;
            lastCell.y = firstCell.y;
        }
        else if(direction == 'up'){
            lastCell.x = firstCell.x;
            lastCell.y = firstCell.y - 20;
        }
        else if(direction == 'down'){
            lastCell.x = firstCell.x;
            lastCell.y = firstCell.y + 20;
        }

        objectToMove_snake.push(lastCell);
        firstCell = lastCell;


        if(addNew){
            objectToMove_snake.unshift(game.add.sprite(oldLastCellx, oldLastCelly, 'snake'));
            objectToMove_snake[0].scale.setTo(0.3125, 0.3125);
            addNew = false;
        }
        pixelCollision();
        wallCollision();
        selfColision();
    }

}



function pixelCollision() {
    for(var i = 0; i < objectToMove_snake.length; i++)
        if(objectToMove_snake[i].x == appleSprite_200440.x && objectToMove_snake[i].y == appleSprite_200440.y){
            addNew = true;
            appleSprite_200440.destroy();
            randomPosition_200440();
            // VAR_INC();
        }
}

function selfColision() {
    var head = objectToMove_snake[objectToMove_snake.length - 1];
    for(var i = 0; i < objectToMove_snake.length - 1; i++)
        if(head.x == objectToMove_snake[i].x && head.y == objectToMove_snake[i].y)
            game.state.start('FinalState');
}

function wallCollision() {
    // if(CAN_OVER){
        var head = objectToMove_snake[objectToMove_snake.length - 1];
        if(head.x >= 30*20 || head.x < 0 || head.y >= 22*20 || head.y < 0)
            game.state.start('FinalState');
    // }
}
//EVENTS_FUNCTIONS