var cursors;

//GLOBAL_MOVING_GROUP_CODE

//GLOBAL_MOVING_GROUP_CODE

var FinalState = {

    preload : function() {
//PRELOAD

//BCKGRND

//BCKGRND


//PAINTS

//PAINTS


//PRELOAD
    },

    create: function () {

	// Set up a Phaser controller for keyboard input.
    cursors = game.input.keyboard.createCursorKeys();
        
//CREATE

//STBCKGRND
    game.stage.backgroundColor = '#ffffff';
//STBCKGRND



//PIXELS

//PIXELS



//F_CALL_EVENTS

//F_CALL_EVENTS


//CREATE
    },

    update: function () {
//UPDATE

//F_CALL_UPDATE_FUNC

//F_CALL_UPDATE_FUNC

//UPDATE
    },

	nextState: function(){
//NXTSTATE

//NXTSTATE
    }

};



//EVENTS_FUNCTIONS

//EVENTS_FUNCTIONS